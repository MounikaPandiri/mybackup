#!/bin/bash
sudo echo "node loadbalancer-vlb inherits lbaas {}" >> /etc/puppet/manifests/site.pp
sudo echo "node ims-vbono inherits base_bono {}" >> /etc/puppet/manifests/site.pp
sudo echo "node ims-vsprout inherits base_sprout {}" >> /etc/puppet/manifests/site.pp
sudo echo "node ims-vellis inherits base_ellis {}" >> /etc/puppet/manifests/site.pp
sudo echo "node ims-vhomer inherits base_homer {}" >> /etc/puppet/manifests/site.pp
sudo echo "node ims-vhs inherits base_homestead {}" >> /etc/puppet/manifests/site.pp
sudo echo "node ims-vhomer-hs inherits base_homer_homestead {}" >> /etc/puppet/manifests/site.pp
sudo echo "node ims-vbono-ellis inherits base_bono_ellis {}" >> /etc/puppet/manifests/site.pp
sudo echo "node ims-vhomer-hs-sprout inherits base_homestead_homer_sprout {}" >> /etc/puppet/manifests/site.pp
sudo echo "node ims-vims inherits base_all_in_one {}" >> /etc/puppet/manifests/site.pp
sudo echo "node dhcpdns-vdhcpdns inherits base_dns {}" >> /etc/puppet/manifests/site.pp
echo "TEST" > /tmp/sample.txt
