echo "#define RELEASE 5" > platform/curversion.h
